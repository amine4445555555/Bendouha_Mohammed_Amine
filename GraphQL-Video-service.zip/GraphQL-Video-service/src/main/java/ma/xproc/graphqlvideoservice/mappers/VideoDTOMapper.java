package ma.xproc.graphqlvideoservice.mappers;

import ma.xproc.graphqlvideoservice.dao.entities.Video;
import ma.xproc.graphqlvideoservice.dto.VideoDTO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VideoDTOMapper{
    private final ModelMapper modelMapper;

    @Autowired
    public VideoDTOMapper(ModelMapper modelMapper){
        this.modelMapper = modelMapper;
    }

    public VideoDTO fromVideoToVideoDto(Video video){
        return modelMapper.map(video, VideoDTO.class);
    }

    public Video fromVideoDtoToVideo(VideoDTO videoDTO){
        return modelMapper.map(videoDTO, Video.class);
    }
}
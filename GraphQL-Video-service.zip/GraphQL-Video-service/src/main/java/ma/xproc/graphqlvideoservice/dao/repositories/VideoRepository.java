package ma.xproc.graphqlvideoservice.dao.repositories;

import ma.xproc.graphqlvideoservice.dao.entities.Video;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VideoRepository extends JpaRepository<Video, Long> {
}
